Use the (free) TI Connect CE desktop software for PC or Mac to drag and drop either the .8xv or the .py files onto your connected calculator.

https://education.ti.com/en/products/computer-software/ti-connect-ce-sw

