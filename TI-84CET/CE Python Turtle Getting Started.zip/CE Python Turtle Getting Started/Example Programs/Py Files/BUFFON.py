from ti_system import *
from random import *

# use shell before entering turtle environment
disp_clr()
length=int(input("Length of needle or [enter] for 50 ? ") or '50')
spacing=int(input("Spacing among lines or [enter] for 50 ? ") or '50')
needles=int(input("How many needles  or [enter] for 60 ? ") or '60')
the_pies=[]
the_count=[]
# set up turtle environment
from turtle import *; t=Turtle()
t.hidegrid()
t.hideturtle()
t.pensize(2)
t.speed(0)
w,h=320,210

the_lines=[] # list of all x-coordinate of all lines
n_lines=int((w/spacing)/2)+2 # number of lines
crossing = 0 # needles crossing a line
estimate = 0 # calculated estimate of pi
# draw all of the lines and append the_lines
for x in range(-n_lines*spacing,(n_lines+1)*spacing,spacing):
  the_lines.append(x)
  t.penup()
  t.goto(x,-h/2)
  t.pendown()
  t.goto(x,h/2)

# draw the needles
for i in range(needles+1):
  x1=randint(0,w)-w//2
  y1=randint(0,h)-h//2
  angle=random()*360
  t.penup()
  t.goto(x1,y1)
  t.setheading(angle)
  t.forward(length)
  x2= t.xcor()
  y2= t.ycor()
  t.pencolor(255,0,0)
# check if needle touches or crosses a line
  for n in range(len(the_lines)):
    if((x1<=the_lines[n] and x2>=the_lines[n]) or (x2<=the_lines[n] and x1>=the_lines[n])):
      t.pencolor(0,255,0)
      crossing+=1
  t.pendown()
  t.goto(x1,y1)
# Buffon's formula
  try: 
    estimate=(2*length*i)/(crossing*spacing)
  except:
# all fun and games until somone divides by zero
    pass
  the_pies.append(estimate)
  the_count.append(i)
store_list("1",the_count)
store_list("2",the_pies)
error=(pi-estimate)*100/pi
sleep(2)

disp_at(7,"    Press [clear] to continue","left")
disp_wait()
disp_clr()
print("")
print("Estimate of \n  Pi =", estimate,"\n  Error =",error,"%\n")
print("Next, exit the Python App and\ncreate a Stat Plot with L1 and  L2 to see data, Zoom 9:StatPlot.")
print("\nPress [clear] to continue")
t.done()