from random import randint
from ti_system import escape
from turtle import *
t=Turtle()
t.hidegrid()
t.hideturtle()
t.speed(0)
while not escape():
  t.penup()
  t.goto(randint(-200,200),randint(-110,100))
  t.pendown()
  t.pencolor(randint(0,255),randint(0,255),randint(0,255))
  b=randint(5,60)
  h=randint(5,60)
  for i in range(2):
    t.forward(b)
    t.left(90)
    t.forward(h)
    t.left(90)
t.done()
