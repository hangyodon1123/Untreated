from random import *
from time import *
from turtle import *
t=Turtle()
t.hideturtle()
t.pensize(2)
t.speed(10)
while not escape():
  t.penup()
  t.goto(-90,16)
  t.pendown()
  t.pencolor(randint(0,255),randint(0,255),randint(0,255))
  t.fillcolor(randint(0,255),randint(0,255),randint(0,255))
  t.begin_fill()
  while True:
    t.forward(180)
    t.right(160)
    h=t.heading()
    if h<2:
      break
  t.end_fill()
  sleep(1.5)
t.done()
