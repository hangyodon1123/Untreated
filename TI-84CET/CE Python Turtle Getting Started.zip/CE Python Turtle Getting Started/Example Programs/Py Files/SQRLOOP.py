from random import randint
from ti_system import escape
from math import sqrt
from time import sleep
from turtle import *
t=Turtle()
t.speed(0)
t.pensize(3)
t.hideturtle()
while not escape():
  d=200
  t.penup()
  t.goto(-d/2,-d/2)
  t.setheading(0)
  t.pendown()
  for i in range(8):
    t.fillcolor(randint(0,255),randint(0,255),randint(0,255))
    t.begin_fill()
    for j in range(4):
      t.forward(d)
      t.left(90)
    t.end_fill()
    t.penup()
    t.forward(d/2)
    t.left(45)
    t.pendown()
    d=sqrt((d**2)+(d**2))/2
  sleep(1.5)
t.done()