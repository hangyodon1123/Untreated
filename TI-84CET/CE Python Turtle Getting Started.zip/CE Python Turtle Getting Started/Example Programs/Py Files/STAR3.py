from random import randint
from time import sleep
from turtle import *
t=Turtle()
t.pensize(1)
t.hideturtle()
t.speed(0)
while not escape():
  t.penup()
  t.goto(randint(-200,120),randint(-100,100))
  t.pendown()
  t.pencolor(randint(0,255),randint(0,255),randint(0,255))
  t.fillcolor(randint(0,255),randint(0,255),randint(0,255))
  t.begin_fill()
  while True:
    t.forward(80)
    t.right(162)
    h=t.heading()
    if h<2:
      break
  t.end_fill()
t.done()
