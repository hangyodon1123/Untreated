from random import *
from turtle import *
t=Turtle()
t.hideturtle()
t.speed(1)
h=0
while not escape():
  t.pensize(2)
  r=randint(0,255)
  g=randint(0,255)
  b=randint(0,255)
  t.pencolor(r,g,b)
  x=randint(-150,150)
  y=randint(-100,100)
  t.forward(80)
  t.dot(randint(5,60))
  t.penup()
  t.home()
  t.pendown()
  h-=45
  t.setheading(h)
t.done()