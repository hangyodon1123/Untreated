from random import randint
from turtle import *
t=Turtle()
t.hideturtle()
t.hidegrid()
t.speed(0)
for j in range(112,-150,-84):
  for i in range(-169,170,86):
    t.penup()
    t.goto(i,j)
    t.pendown()
    t.pencolor(randint(0,255),randint(0,255),randint(0,255))
    while True:
      t.forward(80)
      t.left(140)
      h=t.heading()
      if h<1:
        break
t.done()