from random import *
from turtle import *
t=Turtle()
t.pensize(2)
t.penup()
t.goto(-90,16)
t.pendown()
t.pencolor(randint(0,255),randint(0,255),randint(0,255))
t.fillcolor(randint(0,255),randint(0,255),randint(0,255))
t.begin_fill()
while True:
  t.forward(180)
  t.right(160)
  if t.heading()<1:
    break
t.end_fill()
t.done()
